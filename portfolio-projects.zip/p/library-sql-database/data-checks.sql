-- Проверки качества данных. Каждый запрос должен вернуть 0 строк.

-- 1. Выдачи со ссылкой на несуществующую книгу
SELECT * FROM loans
WHERE book_id NOT IN (SELECT book_id FROM books);

-- 2. Выдачи со ссылкой на несуществующего читателя
SELECT * FROM loans
WHERE reader_id NOT IN (SELECT reader_id FROM readers);

-- 3. Дата возврата раньше даты выдачи
SELECT * FROM loans
WHERE return_date IS NOT NULL AND return_date < loan_date;

-- 4. Дубликаты email читателей
SELECT email, COUNT(*) FROM readers
GROUP BY email HAVING COUNT(*) > 1;

-- 5. Книги с отрицательным числом экземпляров
SELECT * FROM books WHERE copies < 0;

-- 6. Больше выданных книг, чем экземпляров в библиотеке
SELECT b.title, b.copies, COUNT(l.loan_id) AS on_hand
FROM books b
JOIN loans l ON l.book_id = b.book_id AND l.return_date IS NULL
GROUP BY b.book_id, b.title, b.copies
HAVING COUNT(l.loan_id) > b.copies;
