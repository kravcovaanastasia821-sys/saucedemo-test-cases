-- 1. Все книги с авторами
SELECT b.title, a.full_name AS author, b.year
FROM books b
JOIN authors a ON a.author_id = b.author_id
ORDER BY b.title;

-- 2. Количество книг у каждого автора
SELECT a.full_name, COUNT(b.book_id) AS books_count
FROM authors a
LEFT JOIN books b ON b.author_id = a.author_id
GROUP BY a.author_id, a.full_name;

-- 3. Книги, которые сейчас на руках (не возвращены)
SELECT b.title, r.full_name AS reader, l.loan_date
FROM loans l
JOIN books b ON b.book_id = l.book_id
JOIN readers r ON r.reader_id = l.reader_id
WHERE l.return_date IS NULL;

-- 4. Читатели, взявшие больше одной книги
SELECT r.full_name, COUNT(*) AS loans_count
FROM loans l
JOIN readers r ON r.reader_id = l.reader_id
GROUP BY r.reader_id, r.full_name
HAVING COUNT(*) > 1;

-- 5. Самые популярные книги
SELECT b.title, COUNT(l.loan_id) AS times_taken
FROM books b
LEFT JOIN loans l ON l.book_id = b.book_id
GROUP BY b.book_id, b.title
ORDER BY times_taken DESC;

-- 6. Книги, которые ни разу не брали
SELECT title FROM books
WHERE book_id NOT IN (SELECT book_id FROM loans);
