CREATE TABLE authors (
    author_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name   TEXT NOT NULL,
    birth_year  INTEGER CHECK (birth_year > 0)
);

CREATE TABLE books (
    book_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    author_id   INTEGER NOT NULL,
    year        INTEGER CHECK (year > 0),
    copies      INTEGER NOT NULL DEFAULT 1 CHECK (copies >= 0),
    FOREIGN KEY (author_id) REFERENCES authors(author_id)
);

CREATE TABLE readers (
    reader_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name   TEXT NOT NULL,
    email       TEXT UNIQUE
);

CREATE TABLE loans (
    loan_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id       INTEGER NOT NULL,
    reader_id     INTEGER NOT NULL,
    loan_date     TEXT NOT NULL,
    return_date   TEXT,
    FOREIGN KEY (book_id) REFERENCES books(book_id),
    FOREIGN KEY (reader_id) REFERENCES readers(reader_id)
);
