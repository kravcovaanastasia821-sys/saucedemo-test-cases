INSERT INTO authors (full_name, birth_year) VALUES
('Лев Толстой', 1828),
('Фёдор Достоевский', 1821),
('Антон Чехов', 1860),
('Михаил Булгаков', 1891);

INSERT INTO books (title, author_id, year, copies) VALUES
('Война и мир', 1, 1869, 3),
('Анна Каренина', 1, 1877, 2),
('Преступление и наказание', 2, 1866, 4),
('Идиот', 2, 1869, 1),
('Вишнёвый сад', 3, 1904, 2),
('Мастер и Маргарита', 4, 1967, 5);

INSERT INTO readers (full_name, email) VALUES
('Иван Петров', 'ivan@example.com'),
('Мария Сидорова', 'maria@example.com'),
('Алексей Иванов', 'alexey@example.com');

INSERT INTO loans (book_id, reader_id, loan_date, return_date) VALUES
(1, 1, '2026-09-01', '2026-09-15'),
(3, 1, '2026-09-10', NULL),
(6, 2, '2026-09-12', '2026-09-20'),
(3, 3, '2026-09-18', NULL),
(5, 2, '2026-10-01', NULL);
